// Question : Write a separate program using sigaction system call to catch `SIGSEGV` signal
/*
Name:Ramji kumar
RollNo.:MT2024123
subject:SS HandsOnList2

OUTPUT:

tware/Hands-On-List-2/"10a
Caught signal SIGSEGV (11)

*/
#include <signal.h> // Import for `sigaction`, `raise`
#include <stdio.h>  // Import for `perror` & `printf`
#include <unistd.h> // Import for `_exit(0)`
void signalHandler(int signalNumber)
{
    printf("Caught signal SIGSEGV (%d)\n", signalNumber);
    _exit(0); // Exit the program immediately
}

int main()
{
    int status; // Determines success of `sigaction` call
    struct sigaction sg;

    sg.sa_handler = signalHandler; // Set the signal handler
    sg.sa_flags = 0;               // No special flags

    // Set the signal handler for SIGSEGV
    status = sigaction(SIGSEGV, &sg, NULL);
    if (status == -1)
    {
        perror("Error while setting signal handler!");
        return 1; // Return an error code if sigaction fails
    }
    else
    {
        raise(SIGSEGV); // Raise SIGSEGV to test the handler
    }

    return 0; // Return 0 for successful completion
}
