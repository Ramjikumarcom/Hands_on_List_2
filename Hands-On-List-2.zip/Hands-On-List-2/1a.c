// Question 1.a: Write a separate program (for each time domain) to set a interval timer in 10s and 10ms - `ITIMER_REAL`

/*
Name:Ramji kumar
RollNo.:MT2024123
subject:SS HandsOnList2

OUTPUT:
// output is dependent of input time using getchar
for arg[1]=1->
for arg[1]=2->

*/

#include <sys/time.h> // Import `setitimer`
#include <signal.h>   // Import for `signal`
#include <unistd.h>   // Import for `pause`
#include <stdio.h>    // Import `perror` & `printf`

void main(int argc, char *argv[])
{
    int timestat; // Determines success of `setitimer` call

    struct itimerval timer;

    if (argc != 2)
    {
        printf("Pass 1 for 10s timer or 2 for 10ms timer\n");
        _exit(0);
    }

    if ((int)(*argv[1] - 48) == 1)
    {
        // Setting a interval timer for 10s
        timer.it_interval.tv_sec = 0;
        timer.it_interval.tv_usec = 0;
        timer.it_value.tv_sec = 10;
        timer.it_value.tv_usec = 0;
    }
    else if ((int)(*argv[1] - 48) == 2)
    {
        // Setting a interval timer for 10ms
        timer.it_interval.tv_sec = 0;
        timer.it_interval.tv_usec = 0;
        timer.it_value.tv_sec = 0;
        timer.it_value.tv_usec = 10000;
    }

    timestat = setitimer(ITIMER_REAL, &timer, 0);

    char A = getchar(); // it is used for input

    if (timestat == -1)
        perror("Error while setting an interval timer!");

    while (1)
        printf("%c", A);
}