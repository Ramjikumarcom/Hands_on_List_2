// Question : Write a simple program to create three threads.
/*
Name:Ramji kumar
RollNo.:MT2024123
subject:SS HandsOnList2

OUTPUT:
Running in thread: 140420677891776
Running in thread: 140420669499072
Running in thread: 140420661106368

*/
#include <pthread.h> // Import for `pthread_create`, `pthread_self`
#include <stdio.h>   // Import for `perror` & `printf`
#include <unistd.h>  // Import `sleep`

void *sampleFunction(void *data)
{
    printf("Running in thread: %lu\n", pthread_self());
}

void main()
{
    pthread_t threadOne, threadTwo, threadThree;

    // Create three threads
    if (pthread_create(&threadOne, NULL, sampleFunction, NULL)) // pthread_create returns 0 on success.
        perror("Error while creating thread one");
    if (pthread_create(&threadTwo, NULL, sampleFunction, NULL))
        perror("Error while creating thread two");
    if (pthread_create(&threadThree, NULL, sampleFunction, NULL))
        perror("Error while creating thread three");

    // Wait for the threads to terminate and then terminate the main process
    pthread_exit(NULL);
}
